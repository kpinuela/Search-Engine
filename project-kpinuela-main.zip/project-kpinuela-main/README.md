Search Engine
=================================================

The project is broken into two separate GitHub repositories and Eclipse Java projects. This is the private individual repository for your project source code.

Unlike the shared public tests repository, this repository is only accessible by you, the instructor, and the teacher assistants.
